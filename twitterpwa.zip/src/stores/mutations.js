export default {
    'ALTERA_CONTA' (state, payload) {
        state.conta = payload
    }
}