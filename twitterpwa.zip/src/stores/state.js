export default {
    conta: {
        profile_image_url: '',
        screen_name: '',
    }
}